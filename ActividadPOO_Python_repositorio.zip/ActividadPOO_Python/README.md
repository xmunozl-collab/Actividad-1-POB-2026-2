# Actividad 1 – Programación Orientada a Objetos

**Universidad Nacional de Colombia**

**Nombre de la actividad:** Actividad 1 – Individual (Valor 10%) – Programación Orientada a Objetos 2026-2S

**Nombre completo del estudiante:** Ximena Muñoz Lara

**Nombre completo del docente:** Walter Hugo Arboleda Mazo

## Descripción

Este repositorio contiene la solución en Python de los cinco ejercicios de lógica de
programación (tomados del libro *Lógica de Programación* de Efraín Oviedo Regino)
solicitados en la Actividad 1, implementados usando clases, atributos y métodos.

## Contenido

| Archivo | Ejercicio |
|---|---|
| `src/edad_familia.py` | Ejercicio Resuelto No. 4 – Edades de la familia |
| `src/seguimiento_instrucciones.py` | Ejercicio Resuelto No. 5 – Seguimiento de instrucciones |
| `src/empleado.py` | Ejercicio Propuesto No. 12 – Salario del empleado |
| `src/numero.py` | Ejercicio Propuesto No. 14 – Cuadrado y cubo de un número |
| `src/circulo.py` | Ejercicio Propuesto No. 17 – Área y circunferencia de un círculo |

## Cómo ejecutar

Cada ejercicio es independiente y se ejecuta directamente con Python 3. Por ejemplo,
para el ejercicio 4:

```bash
cd src
python3 edad_familia.py
```

Repita el mismo procedimiento cambiando el nombre del archivo para los demás
ejercicios (`seguimiento_instrucciones.py`, `empleado.py`, `numero.py`, `circulo.py`).

## Documento de entrega

El archivo `Actividad1_POO_Python.pdf`, en la raíz del repositorio, contiene la
portada, el código fuente y el diagrama de clases de cada ejercicio, tal como lo
exige el enunciado de la actividad.
